''' Proof-of-Concept chess problem server by Sir Ckopo

Made just to test a little networking feature of GuezzDaChezz app
'''

import SocketServer
import time
import json
import subprocess
import random

db_name = 'problems.txt'

def init_db():
    f = open(db_name, 'r');
    data = f.read()
    l = data.strip().splitlines()
    return l

problems = init_db()

def get_fen():
    return problems[random.randrange(len(problems))]

def get_data(fen):
    p = subprocess.Popen(['ckChessieTSW', '--short', 'solve', fen],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    o, err = p.communicate()
    out = o.strip().splitlines()
    return out

def get_json():
    o = {'answer':'ok','fen':'', 'solutions':'', 'answers':''}
    a = get_data(get_fen())
    o['fen'], o['solutions'] = a
    print o
    return json.dumps(o)

class MyTCPServer(SocketServer.ThreadingTCPServer):
    allow_reuse_address = True

class MyTCPServerHandler(SocketServer.BaseRequestHandler):
    def handle(self):
        try:
            data = json.loads(self.request.recv(1024).strip())
            if data['type'] == 'ping':                
                print ('[' + time.ctime() + '] A ping recieved from ' +
                       self.client_address[0] + '!')
                self.request.sendall(json.dumps({'answer':'pong'}))
            elif data['type'] == 'random':
                print ('[' + time.ctime() + '] A random problem requested ' +
                       'from ' + self.client_address[0])
                self.request.sendall(get_json())
            else:
                print ('[' + time.ctime() + '] Plain signal from ' +
                       self.client_address[0] + ', sending a plain answer')
                self.request.sendall(json.dumps({'answer':'derp'}))
        except Exception, e:
            print '[' + time.ctime() + '] !! Exception while receiving message: ', e

if (__name__ == "__main__"):
    try:
        print '[' + time.ctime() + '] The problem server is going up at port 13373!'
        print '[' + time.ctime() + '] TIP: press Ctrl-C to stop'
        server = MyTCPServer(("", 13373), MyTCPServerHandler)
        server.serve_forever()
    except KeyboardInterrupt:
        print '[' + time.ctime() + '] Ctrl-C sent, going down'
    
